import TelegramBot from 'node-telegram-bot-api';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

let bot = null;
let isPolling = false;
let pollingRetries = 0;
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;

const REQUIRED_CHANNELS = [
  '-1002285035548', // Channel 1
  '-1002437679167'  // Channel 2 - Using the actual channel ID from the safeguard link
];

const TOKEN_TO_USDT_RATE = 0.005; // 1000 tokens = 5 USDT

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

async function initBot() {
  if (bot) {
    try {
      isPolling = false;
      await bot.stopPolling({ cancel: true });
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (error) {
      console.error('Error stopping existing bot:', error);
    }
  }

  try {
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });
    
    await bot.deleteWebHook({ drop_pending_updates: true });
    
    bot.on('polling_error', async (error) => {
      console.error('Polling error:', error);
      
      if (error.code === 'ETELEGRAM' && error.message.includes('Conflict')) {
        if (pollingRetries < MAX_RETRIES) {
          pollingRetries++;
          console.log(`Detected polling conflict, attempting to reconnect... (Attempt ${pollingRetries}/${MAX_RETRIES})`);
          await restartPolling();
        } else {
          console.error('Max polling retries reached. Shutting down bot...');
          await shutdown();
        }
      }
    });

    setupBotHandlers();
    await startPolling();
    
    console.log('Bot initialized successfully');
  } catch (error) {
    console.error('Failed to initialize bot:', error);
    throw error;
  }
}

async function startPolling() {
  if (isPolling) {
    return;
  }

  try {
    isPolling = true;
    await bot.startPolling({
      polling: {
        interval: 300,
        autoStart: true,
        params: {
          timeout: 10
        }
      }
    });
    console.log('Bot polling started successfully');
    pollingRetries = 0;
  } catch (error) {
    console.error('Failed to start polling:', error);
    isPolling = false;
    if (pollingRetries < MAX_RETRIES) {
      setTimeout(() => restartPolling(), RETRY_DELAY);
    } else {
      console.error('Max polling retries reached. Shutting down bot...');
      await shutdown();
    }
  }
}

async function restartPolling() {
  console.log('Restarting bot polling...');
  isPolling = false;
  try {
    await bot.stopPolling({ cancel: true });
    await new Promise(resolve => setTimeout(resolve, 2000));
    await startPolling();
  } catch (error) {
    console.error('Error during polling restart:', error);
    if (pollingRetries < MAX_RETRIES) {
      setTimeout(() => restartPolling(), RETRY_DELAY);
    } else {
      console.error('Max polling retries reached. Shutting down bot...');
      await shutdown();
    }
  }
}

async function shutdown() {
  console.log('Shutting down bot...');
  if (bot) {
    try {
      isPolling = false;
      await bot.stopPolling({ cancel: true });
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (error) {
      console.error('Error stopping bot:', error);
    }
  }
  process.exit(0);
}

function generateReferralCode(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

const userStates = new Map();

const PROFILE_STEPS = {
  NAME: 'name',
  AGE: 'age',
  COMPLETE: 'complete'
};

async function checkChannelSubscription(userId) {
  try {
    let subscriptionStatus = [];
    
    for (const channelId of REQUIRED_CHANNELS) {
      try {
        const member = await bot.getChatMember(channelId, userId);
        const isSubscribed = ['member', 'administrator', 'creator'].includes(member.status);
        subscriptionStatus.push({ channelId, isSubscribed });
      } catch (error) {
        console.error(`Error checking membership for channel ${channelId}:`, error);
        // If we can't verify the subscription, assume it's not subscribed
        subscriptionStatus.push({ channelId, isSubscribed: false });
      }
    }
    
    // Log subscription status for debugging
    console.log('Subscription status:', JSON.stringify(subscriptionStatus, null, 2));
    
    // Only return true if ALL channels are subscribed
    return subscriptionStatus.every(status => status.isSubscribed);
  } catch (error) {
    console.error('Error checking channel subscriptions:', error);
    return false;
  }
}

async function initializeUser(userId, username) {
  try {
    const { data: existingUser, error: selectError } = await supabase
      .from('users')
      .select('*')
      .eq('telegram_id', userId)
      .single();

    if (selectError && selectError.code !== 'PGRST116') {
      console.error('Error checking existing user:', selectError);
      return null;
    }

    if (existingUser) {
      return existingUser;
    }

    const referralCode = generateReferralCode();
    const { data: newUser, error: insertError } = await supabase
      .from('users')
      .insert({
        telegram_id: userId,
        username: username || '',
        tokens: 0,
        referral_code: referralCode,
        referred_users: 0,
        profile_completed: false,
        channels_joined: false
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error creating new user:', insertError);
      return null;
    }

    return newUser;
  } catch (error) {
    console.error('Unexpected error in initializeUser:', error);
    return null;
  }
}

async function getUserStats(userId) {
  try {
    const { data, error } = await supabase
      .from('users')
      .select()
      .eq('telegram_id', userId)
      .single();
    
    if (error) {
      console.error('Error fetching user stats:', error);
      return null;
    }
    
    return data;
  } catch (error) {
    console.error('Error in getUserStats:', error);
    return null;
  }
}

async function processReferral(referralCode, newUserId) {
  try {
    const { data: referrer, error } = await supabase
      .from('users')
      .select()
      .eq('referral_code', referralCode)
      .single();

    if (error) {
      console.error('Error fetching referrer:', error);
      return false;
    }

    if (referrer && referrer.telegram_id !== newUserId) {
      // Store the referral but don't award tokens yet
      const { error: updateError } = await supabase
        .from('users')
        .update({ 
          referred_by: referrer.telegram_id
        })
        .eq('telegram_id', newUserId);

      if (updateError) {
        console.error('Error updating referral:', updateError);
        return false;
      }
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error in processReferral:', error);
    return false;
  }
}

async function awardReferralTokens(userId) {
  try {
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('referred_by, channels_joined')
      .eq('telegram_id', userId)
      .single();

    if (userError || !user.referred_by || user.channels_joined) {
      return;
    }

    const { data: referrer, error: referrerError } = await supabase
      .from('users')
      .select('tokens, referred_users')
      .eq('telegram_id', user.referred_by)
      .single();

    if (referrerError) {
      console.error('Error fetching referrer for token award:', referrerError);
      return;
    }

    const { error: updateError } = await supabase
      .from('users')
      .update({ 
        tokens: referrer.tokens + 100,
        referred_users: referrer.referred_users + 1
      })
      .eq('telegram_id', user.referred_by);

    if (updateError) {
      console.error('Error awarding referral tokens:', updateError);
      return;
    }

    const { error: userUpdateError } = await supabase
      .from('users')
      .update({ channels_joined: true })
      .eq('telegram_id', userId);

    if (!userUpdateError) {
      const usdtValue = (100 * TOKEN_TO_USDT_RATE).toFixed(2);
      bot.sendMessage(user.referred_by, 
        `🎉 Your referral has joined our channels!\nYou earned 100 tokens (≈${usdtValue} USDT after listing)!`
      );
    }
  } catch (error) {
    console.error('Error in awardReferralTokens:', error);
  }
}

async function checkProfile(userId) {
  const { data, error } = await supabase
    .from('users')
    .select('profile_completed, name, age')
    .eq('telegram_id', userId)
    .single();

  if (error) {
    console.error('Error checking profile:', error);
    return false;
  }

  return data?.profile_completed || false;
}

async function updateProfile(userId, field, value) {
  try {
    const updateData = {
      [field]: value
    };

    if (field === 'age') {
      updateData.profile_completed = true;
    }

    const { error } = await supabase
      .from('users')
      .update(updateData)
      .eq('telegram_id', userId);

    if (error) {
      console.error('Error updating profile:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error in updateProfile:', error);
    return false;
  }
}

function startProfileCreation(userId) {
  userStates.set(userId, { step: PROFILE_STEPS.NAME });
  return bot.sendMessage(userId, 
    '👤 Let\'s create your profile!\n\nPlease enter your name:'
  );
}

function getSubscriptionKeyboard() {
  return {
    inline_keyboard: [
      [{ text: '📢 Join Channel 1', url: 'https://t.me/Moji_coin' }],
      [{ text: '📢 Join Channel 2', url: 'http://t.me/safeguard?start=-1002437679167' }],
      [{ text: '✅ Check Subscription', callback_data: 'check_subscription' }]
    ]
  };
}

function setupBotHandlers() {
  bot.onText(/\/start(?:\s+(\w+))?/, async (msg, match) => {
    try {
      const userId = msg.from.id;
      const username = msg.from.username;
      
      console.log('Starting user initialization for:', userId, username);
      const user = await initializeUser(userId, username);
      
      if (!user) {
        console.error('Failed to initialize user:', userId);
        bot.sendMessage(userId, '❌ Sorry, there was an error initializing your account. Please try again later.');
        return;
      }

      const referrerCode = match?.[1];
      if (referrerCode && !user.channels_joined) {
        await processReferral(referrerCode, userId);
      }

      const isSubscribed = await checkChannelSubscription(userId);
      console.log(`User ${userId} subscription status:`, isSubscribed);
      
      if (!isSubscribed) {
        bot.sendMessage(userId,
          '🔔 Please join our channels to participate in the referral program:',
          { reply_markup: getSubscriptionKeyboard() }
        );
        return;
      }

      if (!user.channels_joined) {
        await awardReferralTokens(userId);
      }

      if (!user.profile_completed) {
        await startProfileCreation(userId);
        return;
      }

      const keyboard = {
        keyboard: [
          [{ text: '💰 Balance' }],
          [{ text: '🔗 Generate Referral Link' }],
          [{ text: '👥 Referred Users' }]
        ],
        resize_keyboard: true
      };

      bot.sendMessage(userId, 
        'Welcome back to Moji Coin Referral Bot! 🎉\nEarn tokens by referring friends!\n\n💎 After listing: 1000 tokens = 5 USDT',
        { reply_markup: keyboard }
      );
    } catch (error) {
      console.error('Error in start command:', error);
      bot.sendMessage(msg.from.id, '❌ An error occurred. Please try again later.');
    }
  });

  bot.on('callback_query', async (query) => {
    const userId = query.from.id;

    if (query.data === 'check_subscription') {
      const isSubscribed = await checkChannelSubscription(userId);
      console.log(`Subscription check for user ${userId}:`, isSubscribed);
      
      if (isSubscribed) {
        await awardReferralTokens(userId);
        const user = await getUserStats(userId);
        
        if (!user.profile_completed) {
          await startProfileCreation(userId);
        } else {
          const keyboard = {
            keyboard: [
              [{ text: '💰 Balance' }],
              [{ text: '🔗 Generate Referral Link' }],
              [{ text: '👥 Referred Users' }]
            ],
            resize_keyboard: true
          };

          bot.sendMessage(userId,
            '✅ Thank you for joining our channels!\nWelcome to Moji Coin Referral Bot! 🎉\nEarn tokens by referring friends!\n\n💎 After listing: 1000 tokens = 5 USDT',
            { reply_markup: keyboard }
          );
        }
        
        bot.answerCallbackQuery(query.id, {
          text: '✅ Subscription verified successfully!',
          show_alert: true
        });
      } else {
        bot.answerCallbackQuery(query.id, {
          text: '❌ Please join both channels first!',
          show_alert: true
        });
      }
    }
  });

  bot.on('message', async (msg) => {
    try {
      const userId = msg.from.id;
      const text = msg.text;

      const userState = userStates.get(userId);
      if (userState) {
        switch (userState.step) {
          case PROFILE_STEPS.NAME:
            if (text.length < 2 || text.length > 50) {
              bot.sendMessage(userId, '❌ Please enter a valid name (2-50 characters)');
              return;
            }
            await updateProfile(userId, 'name', text);
            userStates.set(userId, { step: PROFILE_STEPS.AGE });
            bot.sendMessage(userId, '👍 Name saved! Now please enter your age:');
            return;

          case PROFILE_STEPS.AGE:
            const age = parseInt(text);
            if (isNaN(age) || age < 13 || age > 100) {
              bot.sendMessage(userId, '❌ Please enter a valid age (13-100)');
              return;
            }
            await updateProfile(userId, 'age', age);
            userStates.delete(userId);

            const keyboard = {
              keyboard: [
                [{ text: '💰 Balance' }],
                [{ text: '🔗 Generate Referral Link' }],
                [{ text: '👥 Referred Users' }]
              ],
              resize_keyboard: true
            };

            bot.sendMessage(userId, 
              '✅ Profile completed!\nWelcome to Moji Coin Referral Bot! 🎉\nEarn tokens by referring friends!\n\n💎 After listing: 1000 tokens = 5 USDT',
              { reply_markup: keyboard }
            );
            return;
        }
      }

      const isSubscribed = await checkChannelSubscription(userId);
      if (!isSubscribed) {
        bot.sendMessage(userId,
          '🔔 Please join our channels to participate in the referral program:',
          { reply_markup: getSubscriptionKeyboard() }
        );
        return;
      }

      switch (text) {
        case '💰 Balance': {
          const stats = await getUserStats(userId);
          if (!stats) {
            bot.sendMessage(userId, '❌ Error fetching your balance. Please try again later.');
            return;
          }
          const usdtValue = (stats.tokens * TOKEN_TO_USDT_RATE).toFixed(2);
          bot.sendMessage(userId, 
            `Your current balance: ${stats.tokens} tokens 💎\nEstimated value after listing: ${usdtValue} USDT`
          );
          break;
        }
        
        case '🔗 Generate Referral Link': {
          const stats = await getUserStats(userId);
          if (!stats) {
            bot.sendMessage(userId, '❌ Error generating referral link. Please try again later.');
            return;
          }
          
          const botUsername = (await bot.getMe()).username;
          const referralLink = `https://t.me/${botUsername}?start=${stats.referral_code}`;
          
          const message = `
🔥 Here's your unique referral link:

${referralLink}

Share this link with friends to earn 100 tokens (≈${(100 * TOKEN_TO_USDT_RATE).toFixed(2)} USDT after listing) for each referral!

Required channels:
1. https://t.me/Moji_coin
2. Join through verification bot

💎 Token Value: 1000 tokens = 5 USDT (after listing)
`;
          bot.sendMessage(userId, message, { disable_web_page_preview: true });
          break;
        }
        
        case '👥 Referred Users': {
          const stats = await getUserStats(userId);
          if (!stats) {
            bot.sendMessage(userId, '❌ Error fetching your referral stats. Please try again later.');
            return;
          }
          const totalTokens = stats.referred_users * 100;
          const usdtValue = (totalTokens * TOKEN_TO_USDT_RATE).toFixed(2);
          bot.sendMessage(userId, 
            `👥 You have referred ${stats.referred_users} users\n💎 Total earnings: ${totalTokens} tokens (≈${usdtValue} USDT after listing)`
          );
          break;
        }
      }
    } catch (error) {
      console.error('Error handling message:', error);
      bot.sendMessage(msg.from.id, '❌ An error occurred. Please try again later.');
    }
  });
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', async (error) => {
  console.error('Uncaught exception:', error);
  await shutdown();
});
process.on('unhandledRejection', async (error) => {
  console.error('Unhandled rejection:', error);
  await shutdown();
});

try {
  await initBot();
} catch (error) {
  console.error('Failed to start bot:', error);
  process.exit(1);
}