/*
  # Create users table for telegram bot

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `telegram_id` (bigint, unique) - Telegram user ID
      - `username` (text) - Telegram username
      - `tokens` (integer) - User's token balance
      - `referral_code` (text, unique) - Unique referral code
      - `referred_users` (integer) - Number of users referred
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on users table
    - Add policies for bot access
*/

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id bigint UNIQUE NOT NULL,
  username text,
  tokens integer DEFAULT 0,
  referral_code text UNIQUE NOT NULL,
  referred_users integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Allow full access for service role" ON users;

-- Create separate policies for different operations
CREATE POLICY "Allow insert for service role"
  ON users
  FOR INSERT
  TO service_role
  WITH CHECK (true);

CREATE POLICY "Allow select for service role"
  ON users
  FOR SELECT
  TO service_role
  USING (true);

CREATE POLICY "Allow update for service role"
  ON users
  FOR UPDATE
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow delete for service role"
  ON users
  FOR DELETE
  TO service_role
  USING (true);